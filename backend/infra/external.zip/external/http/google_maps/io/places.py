from __future__ import annotations

from typing import TypedDict

from msgspec import field

from backend.internal.dto import StructDTO


class AutocompleteRequest(TypedDict, total=False):
    input: str
    language: str
    types: str
    components: str
    location: str
    radius: int
    sessiontoken: str


class PlaceDetailsRequest(TypedDict, total=False):
    place_id: str
    fields: str
    language: str
    sessiontoken: str


class GeocodeRequest(TypedDict, total=False):
    address: str
    latlng: str
    place_id: str
    language: str
    components: str


class StructuredFormatting(StructDTO):
    main_text: str = ""
    secondary_text: str = ""


class MatchedSubstring(StructDTO):
    offset: int = 0
    length: int = 0


class Term(StructDTO):
    offset: int = 0
    value: str = ""


class AutocompletePrediction(StructDTO):
    place_id: str = ""
    description: str = ""
    structured_formatting: StructuredFormatting = field(default_factory=StructuredFormatting)
    terms: list[Term] = field(default_factory=list)
    types: list[str] = field(default_factory=list)
    matched_substrings: list[MatchedSubstring] = field(default_factory=list)


class AutocompleteResponse(StructDTO):
    status: str = ""
    predictions: list[AutocompletePrediction] = field(default_factory=list)


class Location(StructDTO):
    lat: float = 0.0
    lng: float = 0.0


class Geometry(StructDTO):
    location: Location = field(default_factory=Location)


class AddressComponent(StructDTO):
    long_name: str = ""
    short_name: str = ""
    types: list[str] = field(default_factory=list)


class PlaceDetails(StructDTO):
    place_id: str = ""
    name: str = ""
    formatted_address: str = ""
    geometry: Geometry = field(default_factory=Geometry)
    address_components: list[AddressComponent] = field(default_factory=list)
    types: list[str] = field(default_factory=list)
    url: str = ""
    utc_offset: int | None = None


class PlaceDetailsResponse(StructDTO):
    status: str = ""
    result: PlaceDetails | None = None


class GeocodeResult(StructDTO):
    place_id: str = ""
    formatted_address: str = ""
    geometry: Geometry = field(default_factory=Geometry)
    address_components: list[AddressComponent] = field(default_factory=list)
    types: list[str] = field(default_factory=list)


class GeocodeResponse(StructDTO):
    status: str = ""
    results: list[GeocodeResult] = field(default_factory=list)
